// JPetStore — shared front-end behaviour (no backend, in-memory only)

(function () {
  const KEY = '__jpetstore_cart_count';
  // in-memory only (no localStorage per artifact/browser-storage rules) —
  // count resets on full page navigation, which is expected for this static prototype
  window.__cartCount = window.__cartCount || 0;

  window.bumpCart = function bumpCart() {
    window.__cartCount += 1;
    const el = document.getElementById('cartCount');
    if (el) {
      el.textContent = window.__cartCount;
      el.style.transform = 'scale(1.35)';
      setTimeout(() => { el.style.transform = 'scale(1)'; }, 180);
    }
  };

  document.addEventListener('DOMContentLoaded', () => {
    const el = document.getElementById('cartCount');
    if (el) el.textContent = window.__cartCount;

    const cartBtn = document.getElementById('cartBtn');
    if (cartBtn) {
      cartBtn.addEventListener('click', () => {
        cartBtn.style.transform = 'scale(0.9)';
        setTimeout(() => { cartBtn.style.transform = 'scale(1)'; }, 150);
      });
    }
  });
})();
